
package gameoflife;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class MyPanel extends JPanel {

    int ROWS = 0;
    int COLS = 0;
    boolean[][] grid;

    public MyPanel(int rows, int cols, boolean[][] newgrid){
        super();
        ROWS = rows;
        COLS = cols;
        grid = newgrid;

    }

    public void paintComponent(Graphics g){
        double width = this.getWidth()/(double)ROWS;
        double height = this.getHeight()/(double)COLS;
        
        //draw cells
        for (int x = 0; x < ROWS; x++) {
            for (int y = 0; y < COLS; y++) {
                if (grid[x][y] == true){
                    g.setColor(Color.green);
                    g.fillRect((int)Math.round(x*width), (int)Math.round(y*height), (int)width, (int)height);
                }

            }

        }



        //draw gridlines
        for (int i = 0; i < ROWS; i++) {
            g.setColor(Color.black);
            g.drawLine((int)Math.round(i * width), 0, (int)Math.round(i*width), this.getHeight());
            g.drawLine(0, (int)Math.round(i * height), this.getWidth(), (int)Math.round(i * height));

        }
    }

}
