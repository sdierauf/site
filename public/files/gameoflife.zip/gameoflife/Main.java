

package gameoflife;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Main implements MouseListener, ActionListener, Runnable {
    JFrame jf;
    JButton step;
    JButton start;
    JButton stop;
    JLabel gen;
    MyPanel panel;
    Container buttons;
    boolean[][] grid;
    final int ROWS = 60;
    final int COLS = 60;
    int generation = 0;
    boolean stillrunning;

    public Main()  {
        jf = new JFrame();
        jf.setSize(600,600);
        jf.setLayout(new BorderLayout());
        buttons = new Container();
        buttons.setLayout(new GridLayout(1,4));
        step = new JButton ("Step");
        step.addActionListener(this);
        buttons.add(step);
        start = new JButton ("Start");
        start.addActionListener(this);
        buttons.add(start);
        stop = new JButton ("stop");
        stop.addActionListener(this);
        buttons.add(stop);
        gen = new JLabel("Gen:"+generation);
        buttons.add(gen);
        grid = new boolean[ROWS][COLS];
        panel = new MyPanel(ROWS,COLS,grid);
        panel.addMouseListener(this);
        jf.add(buttons, BorderLayout.NORTH);
        
        jf.add(panel, BorderLayout.CENTER);

        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setVisible(true);

    }

   
    public static void main(String[] args) {
        Main m = new Main();
       
    }

    public void mouseClicked(MouseEvent e) {
        
    }

    public void mousePressed(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        double width = panel.getWidth()/(double)ROWS;
        double height = panel.getHeight()/(double)COLS;
        int row = (int)(x/width);
        int col = (int)(y/height);
        grid[row][col] = !grid[row][col];
        jf.repaint();
    }

    public void mouseReleased(MouseEvent e) {
        
    }

    public void mouseEntered(MouseEvent e) {
        
    }

    public void mouseExited(MouseEvent e) {
        
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(step)) {
            step();
        }
         if (e.getSource().equals(start)) {
            stillrunning = true;
            Thread t = new Thread(this);
            t.start();
        }
        if (e.getSource().equals(stop)) {
            stillrunning = false;
        }
        
    }
    public synchronized void step() {
        boolean[][] nextStep = new boolean[ROWS][COLS];
        for (int x = 0; x < ROWS; x++) {
            for (int y = 0; y < COLS; y++) {
                int neighbors = 0;
                if (x-1 >0 && y - 1 > 0 && grid[x-1][y-1] == true) {
                    neighbors++;
                }
                if (x-1 >0  && grid[x-1][y] == true) {
                    neighbors++;
                }
                if (x-1 >0 && y + 1 < COLS && grid[x-1][y+1] == true) {
                    neighbors++;
                }
                if (y + 1 < COLS  && grid[x][y+1] == true) {
                    neighbors++;
                }
                if (y - 1 > 0 && grid[x][y-1] == true) {
                    neighbors++;
                }
                if (x+1 < ROWS && y - 1 > 0 && grid[x+1][y-1] == true) {
                    neighbors++;
                }
                if (x+1 < ROWS &&  grid[x+1][y] == true) {
                    neighbors++;
                }
                if (x+1 < ROWS && y + 1 < COLS && grid[x+1][y+1] == true) {
                    neighbors++;
                }
                if (grid[x][y] == true) {
                    if (neighbors == 2 || neighbors == 3) {
                        nextStep[x][y] = true;
                    }
                    else {
                        nextStep [x][y] = false;
                    }}
                    else {
                        if (neighbors == 3){
                            nextStep[x][y] = true;
                        }
 else{
                            nextStep[x][y] = false;
                    }
                }
            }
            
        }
        for (int x = 0; x < ROWS; x++) {
            for (int y = 0; y < COLS; y++) {
                grid[x][y] = nextStep [x][y];

            }
            
        }
        generation++;
        gen.setText("Gen:"+generation);
        jf.repaint();
    }

    public void run() {
        while (stillrunning == true){
            step();
            try{
                Thread.sleep(80);
            }catch (Exception e)
            {
             e.printStackTrace();
            }
                jf.repaint();
        }

    }




}
